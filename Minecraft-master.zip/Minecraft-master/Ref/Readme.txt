I do not own any of the listed research papers. 
All rights go to their owners.