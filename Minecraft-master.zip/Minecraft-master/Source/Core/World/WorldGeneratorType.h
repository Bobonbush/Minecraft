#pragma once

namespace Minecraft
{
    enum WorldGenerationType 
    {
        Generation_Normal = 0,
        Generation_Islands,
        Generation_Hilly,
        Generation_Flat,
        Generation_FlatWithoutStructures
    };
}