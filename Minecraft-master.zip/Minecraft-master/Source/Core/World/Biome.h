#pragma once
#include <iostream>

namespace Minecraft
{
	enum Biome : uint8_t
	{
		Grassland = 0,
		Plains,
		Ocean,
		Desert,
		Jungle
	};

}