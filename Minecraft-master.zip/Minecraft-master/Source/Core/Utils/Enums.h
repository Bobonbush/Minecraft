#pragma once

#include <iostream>

namespace Minecraft
{
	enum BlockFaceType
	{
		top = 0,
		bottom,
		left,
		right,
		front,
		backward
	};
}